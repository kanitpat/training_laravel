<?php   

    echo  "hello";